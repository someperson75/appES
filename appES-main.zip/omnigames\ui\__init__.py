"""UI module for omniGames."""
from .menu import main, MainMenu

__all__ = ["main", "MainMenu"]
